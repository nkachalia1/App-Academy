class GuessingGame
  
end