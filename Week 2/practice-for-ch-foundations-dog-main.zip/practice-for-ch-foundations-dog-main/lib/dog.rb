class Dog
  
end